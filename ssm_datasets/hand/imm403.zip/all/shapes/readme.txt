


-------------------------------------------------------------------
HANDS - A database of 80 hands recorded December 14th 2001
-------------------------------------------------------------------

by David Delgado Gomez and Mikkel B. Stegmann  {ddg|mbs}@imm.dtu.dk



Image Number	Description
------------------------------------------------
0000-0019	Person 1: Panagiotis Karras
0020-0039	Person 2: David Delgado Gomez
0040-0059	Person 3: Mikkel B. Stegmann
0060-0079	Person 4: Lars Pedersen



The images are available in the following resolutions:

1600x800 JPEG
800x600 JPEG

and annotated in the ASF format. 

[see: AAM-API at http://www.imm.dtu.dk/~aam/ or the matlab dir]